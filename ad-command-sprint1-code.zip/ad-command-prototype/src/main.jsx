import React from "react";
import ReactDOM from "react-dom/client";
import ADCommand from "./ADCommand.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ADCommand />
  </React.StrictMode>
);


if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js"));
}
