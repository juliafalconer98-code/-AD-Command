import React, { useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "ad-command-sprint1-v1";
const T = { paper:"#F5F3EC", card:"#FFFFFF", ink:"#17171B", muted:"#75726A", chart:"#C6F03A", pink:"#FF4D6D", orange:"#FFA13C", blue:"#5FA8FF", yellow:"#FFD83A" };
const fontHead = "'Barlow Semi Condensed', sans-serif";
const fontMono = "'IBM Plex Mono', monospace";

function usePersistentState(key, initialValue){
  const [value,setValue]=useState(()=>{ try { const v=localStorage.getItem(`${STORAGE_KEY}:${key}`); return v?JSON.parse(v):initialValue; } catch { return initialValue; }});
  useEffect(()=>{ try { localStorage.setItem(`${STORAGE_KEY}:${key}`,JSON.stringify(value)); } catch {} },[key,value]);
  return [value,setValue];
}

const initialCrew=[
  {id:"C-01",name:"M. Fraser",dept:"Camera",role:"1st AC",phone:""}, {id:"C-02",name:"K. Osei",dept:"Grip",role:"Key Grip",phone:""},
  {id:"C-03",name:"R. Douglas",dept:"Costume",role:"Costume Supervisor",phone:""}, {id:"C-04",name:"S. Bianchi",dept:"Locations",role:"Location Manager",phone:""},
  {id:"C-05",name:"T. MacLeod",dept:"Art",role:"Art Director",phone:""}, {id:"C-06",name:"J. Park",dept:"Sound",role:"Mixer",phone:""},
  {id:"C-07",name:"A. Nwosu",dept:"Electric",role:"Gaffer",phone:""}, {id:"C-08",name:"E. Ross",dept:"Stunts",role:"Coordinator",phone:""},
];
const initialChannels=[{ch:1,label:"PRODUCTION"},{ch:2,label:"CAMERA"},{ch:3,label:"GRIP / ELECTRIC"},{ch:4,label:"LOCATIONS"},{ch:5,label:"ART / COSTUME"}];
const initialItems=[
  {id:"W-01",type:"Walkie",serial:"MOT-1001",rental:"Highland Comms",cost:425,status:"issued",holderId:"C-01",channel:2,out:"06:20",batteryPct:78,condition:"Good",notes:"",tag:"QR-W-01"},
  {id:"W-02",type:"Walkie",serial:"MOT-1002",rental:"Highland Comms",cost:425,status:"issued",holderId:"C-02",channel:3,out:"06:24",batteryPct:22,condition:"Good",notes:"",tag:"QR-W-02"},
  {id:"W-03",type:"Walkie",serial:"MOT-1003",rental:"Highland Comms",cost:425,status:"available",holderId:null,channel:null,out:null,batteryPct:100,condition:"Good",notes:"",tag:"QR-W-03"},
  {id:"W-04",type:"Walkie",serial:"MOT-1004",rental:"Highland Comms",cost:425,status:"issued",holderId:"C-04",channel:4,out:"06:31",batteryPct:65,condition:"Good",notes:"",tag:"QR-W-04"},
  {id:"W-05",type:"Walkie",serial:"MOT-1005",rental:"Highland Comms",cost:425,status:"available",holderId:null,channel:null,out:null,batteryPct:100,condition:"Good",notes:"",tag:"QR-W-05"},
  {id:"W-06",type:"Walkie",serial:"MOT-1006",rental:"Highland Comms",cost:425,status:"damaged",holderId:null,channel:null,out:null,batteryPct:0,condition:"Damaged",notes:"Cracked antenna housing",tag:"QR-W-06"},
  {id:"B-01",type:"Battery",serial:"BAT-2001",rental:"Highland Comms",cost:68,status:"charging",holderId:null,channel:null,out:null,batteryPct:54,condition:"Good",notes:"Bay 1",tag:"QR-B-01"},
  {id:"B-02",type:"Battery",serial:"BAT-2002",rental:"Highland Comms",cost:68,status:"available",holderId:null,channel:null,out:null,batteryPct:100,condition:"Good",notes:"",tag:"QR-B-02"},
  {id:"H-01",type:"Headset",serial:"HS-3001",rental:"Highland Comms",cost:45,status:"available",holderId:null,channel:null,out:null,batteryPct:null,condition:"Good",notes:"Surveillance kit",tag:"QR-H-01"},
  {id:"CH-01",type:"Charger",serial:"CHR-4001",rental:"Highland Comms",cost:295,status:"available",holderId:null,channel:null,out:null,batteryPct:null,condition:"Good",notes:"6-way charger",tag:"QR-CH-01"},
];

const pad=n=>String(n).padStart(2,"0");
const nowTime=()=>{const d=new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`;};
const uid=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`;
const csvEscape=v=>`"${String(v??"").replaceAll('"','""')}"`;

function Tape({color,children,dark=false}){return <span style={{display:"inline-block",background:color,color:dark?"#fff":T.ink,fontFamily:fontMono,fontSize:10,fontWeight:700,letterSpacing:".08em",padding:"3px 10px 3px 8px",clipPath:"polygon(0 0,100% 0,97% 30%,100% 55%,96% 100%,0 100%,1.5% 60%,0 30%)",whiteSpace:"nowrap"}}>{children}</span>}
function Rule({w=3}){return <div style={{borderTop:`${w}px solid ${T.ink}`}}/>}
function Card({children,style={}}){return <div style={{background:T.card,border:`1.5px solid ${T.ink}`,padding:12,...style}}>{children}</div>}
function Btn({children,onClick,color=T.ink,textColor="#fff",small=false,disabled=false,style={}}){return <button disabled={disabled} onClick={onClick} style={{background:disabled?"#d7d4cd":color,color:disabled?T.muted:textColor,border:`1.5px solid ${T.ink}`,fontFamily:fontHead,fontWeight:800,textTransform:"uppercase",letterSpacing:".05em",fontSize:small?11:13,padding:small?"6px 10px":"10px 14px",cursor:disabled?"not-allowed":"pointer",boxShadow:"2px 2px 0 rgba(23,23,27,.9)",...style}}>{children}</button>}
function SectionHead({kicker,title,right}){return <div style={{marginBottom:8}}><div style={{display:"flex",alignItems:"end",justifyContent:"space-between",gap:10}}><div><div style={{fontFamily:fontMono,fontSize:9,letterSpacing:".2em",color:T.muted}}>{kicker}</div><div style={{fontFamily:fontHead,fontWeight:800,fontSize:23,textTransform:"uppercase",lineHeight:1}}>{title}</div></div>{right}</div><div style={{marginTop:6}}><Rule/></div></div>}
function Field({label,...props}){return <label style={{display:"grid",gap:4,fontFamily:fontMono,fontSize:9,letterSpacing:".12em",color:T.muted}}>{label}<input {...props} style={{border:`1.5px solid ${T.ink}`,padding:"10px",fontFamily:fontMono,fontSize:12,background:T.card,...props.style}}/></label>}
function Select({label,children,...props}){return <label style={{display:"grid",gap:4,fontFamily:fontMono,fontSize:9,letterSpacing:".12em",color:T.muted}}>{label}<select {...props} style={{border:`1.5px solid ${T.ink}`,padding:"10px",fontFamily:fontMono,fontSize:12,background:T.card}}>{children}</select></label>}

export default function ADCommand(){
  const [items,setItems]=usePersistentState("items",initialItems);
  const [crew,setCrew]=usePersistentState("crew",initialCrew);
  const [channels,setChannels]=usePersistentState("channels",initialChannels);
  const [audit,setAudit]=usePersistentState("audit",[]);
  const [view,setView]=usePersistentState("view","BOARD");
  const [query,setQuery]=useState("");
  const [filter,setFilter]=useState("ALL");
  const [modal,setModal]=useState(null);
  const [selected,setSelected]=useState([]);
  const [toast,setToast]=useState(null);
  const [online,setOnline]=useState(()=>navigator.onLine);

  useEffect(()=>{const a=()=>setOnline(true),b=()=>setOnline(false); addEventListener("online",a);addEventListener("offline",b);return()=>{removeEventListener("online",a);removeEventListener("offline",b)}},[]);
  useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(null),2500);return()=>clearTimeout(t)},[toast]);

  const crewById=useMemo(()=>Object.fromEntries(crew.map(c=>[c.id,c])),[crew]);
  const counts=useMemo(()=>({total:items.length,issued:items.filter(i=>i.status==="issued").length,available:items.filter(i=>i.status==="available").length,low:items.filter(i=>i.batteryPct!==null&&i.batteryPct<=25).length,damaged:items.filter(i=>i.status==="damaged"||i.condition==="Damaged").length,charging:items.filter(i=>i.status==="charging").length}),[items]);
  const filtered=useMemo(()=>items.filter(i=>{const holder=crewById[i.holderId];const hay=`${i.id} ${i.type} ${i.serial} ${i.status} ${holder?.name||""} ${holder?.dept||""} ${i.notes||""}`.toLowerCase();const q=hay.includes(query.toLowerCase());const f=filter==="ALL"||i.status.toUpperCase()===filter||i.type.toUpperCase()===filter||filter==="LOW"&&(i.batteryPct!==null&&i.batteryPct<=25);return q&&f}),[items,crewById,query,filter]);

  const log=(action,itemId,detail)=>setAudit(a=>[{id:uid(),at:new Date().toISOString(),time:nowTime(),action,itemId,detail},...a].slice(0,1000));
  const checkIn=(itemId,condition="Good",notes="")=>{const item=items.find(i=>i.id===itemId);const holder=crewById[item?.holderId];setItems(xs=>xs.map(i=>i.id===itemId?{...i,status:condition==="Damaged"?"damaged":"available",holderId:null,channel:null,out:null,condition,notes:notes||i.notes,batteryPct:i.type==="Walkie"?Math.max(i.batteryPct??0,0):i.batteryPct}:i));log("CHECK IN",itemId,`Returned by ${holder?.name||"Unknown"}; condition ${condition}${notes?`; ${notes}`:""}`);setModal(null);setToast(`${itemId} checked in`)};
  const issue=(itemIds,holderId,channel)=>{const h=crewById[holderId];setItems(xs=>xs.map(i=>itemIds.includes(i.id)?{...i,status:"issued",holderId,channel:Number(channel)||null,out:nowTime(),batteryPct:i.batteryPct??100}:i));itemIds.forEach(id=>log("CHECK OUT",id,`Issued to ${h.name} (${h.dept}), channel ${channel||"—"}`));setSelected([]);setModal(null);setToast(`${itemIds.length} item${itemIds.length>1?"s":""} issued to ${h.name}`)};
  const markDamage=(itemId,notes)=>{setItems(xs=>xs.map(i=>i.id===itemId?{...i,status:"damaged",condition:"Damaged",notes}:i));log("DAMAGE",itemId,notes||"Damage reported");setModal(null);setToast(`${itemId} marked damaged`)};
  const addItem=form=>{const item={id:form.id.trim().toUpperCase(),type:form.type,serial:form.serial,rental:form.rental,cost:Number(form.cost)||0,status:"available",holderId:null,channel:null,out:null,batteryPct:form.type==="Walkie"||form.type==="Battery"?100:null,condition:"Good",notes:form.notes,tag:`QR-${form.id.trim().toUpperCase()}`};setItems(x=>[...x,item]);log("CREATE",item.id,`${item.type} added to registry`);setModal(null);setToast(`${item.id} added`)};
  const addCrew=form=>{const person={id:`C-${pad(crew.length+1)}`,name:form.name,dept:form.dept,role:form.role,phone:form.phone};setCrew(x=>[...x,person]);setModal(null);setToast(`${person.name} added`)};
  const exportCSV=()=>{const rows=[["Unit","Type","Serial","Rental House","Cost","Status","Holder","Department","Channel","Time Out","Battery %","Condition","Notes"],...items.map(i=>[i.id,i.type,i.serial,i.rental,i.cost,i.status,crewById[i.holderId]?.name||"",crewById[i.holderId]?.dept||"",i.channel||"",i.out||"",i.batteryPct??"",i.condition,i.notes])];const blob=new Blob([rows.map(r=>r.map(csvEscape).join(",")).join("\n")],{type:"text/csv"});const u=URL.createObjectURL(blob);const a=document.createElement("a");a.href=u;a.download=`ad-command-kit-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(u);setToast("Reconciliation CSV exported")};
  const reset=()=>{if(confirm("Reset all Sprint 1 demo data?")){setItems(initialItems);setCrew(initialCrew);setChannels(initialChannels);setAudit([]);setToast("Demo reset")}};

  return <div style={{minHeight:"100vh",background:T.paper,color:T.ink,paddingBottom:90}}>
    <style>{`@import url('https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:wght@600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap');*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0}button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid ${T.blue};outline-offset:2px}@media(min-width:820px){.shell{max-width:820px;margin:auto;border-left:1px solid #d7d4cd;border-right:1px solid #d7d4cd;min-height:100vh}}`}</style>
    <div className="shell">
      <header style={{padding:"14px"}}><div style={{display:"flex",justifyContent:"space-between",gap:12}}><div><div style={{fontFamily:fontMono,fontSize:9,letterSpacing:".22em",color:T.muted}}>AD COMMAND · SPRINT 1 · <span style={{color:online?"#4c7d00":T.orange}}>{online?"SYNC READY":"OFFLINE · SAVED LOCALLY"}</span></div><div style={{fontFamily:fontHead,fontWeight:800,fontSize:31,textTransform:"uppercase",lineHeight:.95}}>Walkie & Kit<br/>Command</div></div><div style={{textAlign:"right",fontFamily:fontMono}}><div style={{fontSize:22,fontWeight:700}}>{nowTime()}</div><div style={{fontSize:9,color:T.muted}}>DAY 14 · UNIT ONE</div></div></div><div style={{marginTop:10}}><Rule w={5}/></div><div style={{marginTop:2}}><Rule w={1}/></div></header>

      <nav style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:5,padding:"0 14px 12px"}}>{["BOARD","ISSUE","CREW","CHANNELS","AUDIT"].map(v=><button key={v} onClick={()=>setView(v)} style={{padding:"9px 3px",border:`1.5px solid ${T.ink}`,background:view===v?T.ink:T.card,color:view===v?T.chart:T.ink,fontFamily:fontHead,fontWeight:800,fontSize:11,boxShadow:view===v?"none":"2px 2px 0 #17171B",cursor:"pointer"}}>{v}</button>)}</nav>

      <main style={{padding:"0 14px",display:"grid",gap:18}}>
        {view==="BOARD"&&<>
          <section><SectionHead kicker="EXCEPTION-FIRST · LIVE INVENTORY" title="Kit board" right={<Btn small color={T.chart} textColor={T.ink} onClick={()=>setModal({type:"addItem"})}>+ Add item</Btn>}/>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>{[[counts.issued,"OUT",T.orange],[counts.available,"READY",T.chart],[counts.low,"LOW",T.pink],[counts.damaged,"DAMAGED",T.pink],[counts.charging,"CHARGING",T.blue],[counts.total,"TOTAL",T.card]].map(([n,l,c])=><Card key={l} style={{textAlign:"center",background:c}}><div style={{fontFamily:fontHead,fontWeight:800,fontSize:28}}>{n}</div><div style={{fontFamily:fontMono,fontSize:8,letterSpacing:".14em"}}>{l}</div></Card>)}</div>
          </section>
          <section><div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:8}}><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search unit, person, department…" style={{border:`1.5px solid ${T.ink}`,padding:11,fontFamily:fontMono,fontSize:12}}/><Btn small onClick={exportCSV} color={T.card} textColor={T.ink}>Export CSV</Btn></div><div style={{display:"flex",gap:6,overflowX:"auto",padding:"9px 0"}}>{["ALL","ISSUED","AVAILABLE","LOW","DAMAGED","WALKIE","BATTERY"].map(f=><Btn key={f} small onClick={()=>setFilter(f)} color={filter===f?T.yellow:T.card} textColor={T.ink}>{f}</Btn>)}</div>
            <div style={{display:"grid",gap:8}}>{filtered.map(i=>{const h=crewById[i.holderId];return <Card key={i.id} style={{borderLeft:`8px solid ${i.status==="damaged"?T.pink:i.status==="issued"?T.orange:i.status==="charging"?T.blue:T.chart}`}}><div style={{display:"flex",alignItems:"center",gap:10}}><div style={{fontFamily:fontMono,fontWeight:700,width:56}}>{i.id}</div><div style={{flex:1,minWidth:0}}><div style={{fontFamily:fontHead,fontWeight:800,fontSize:16}}>{i.type} · {i.serial}</div><div style={{fontFamily:fontMono,fontSize:9,color:T.muted}}>{h?`${h.name} · ${h.dept} · CH ${i.channel||"—"} · OUT ${i.out}`:`${i.status.toUpperCase()} · ${i.condition}`}</div>{i.notes&&<div style={{fontFamily:fontMono,fontSize:9,marginTop:4}}>{i.notes}</div>}</div>{i.batteryPct!==null&&<Tape color={i.batteryPct<=25?T.pink:i.batteryPct<60?T.yellow:T.chart} dark={i.batteryPct<=25}>{i.batteryPct}%</Tape>}</div><div style={{display:"flex",gap:7,marginTop:10}}>{i.status==="issued"?<Btn small onClick={()=>setModal({type:"return",item:i})}>Scan return</Btn>:i.status!=="damaged"&&<Btn small color={T.chart} textColor={T.ink} onClick={()=>setModal({type:"issue",itemIds:[i.id]})}>Issue</Btn>}<Btn small color={T.card} textColor={T.ink} onClick={()=>setModal({type:"damage",item:i})}>Damage</Btn></div></Card>})}</div>
          </section>
        </>}

        {view==="ISSUE"&&<><section><SectionHead kicker="SCAN-STYLE · BATCH MODE" title="Fast issue"/><Card><div style={{fontFamily:fontHead,fontWeight:800,fontSize:17}}>1. Tap every item being issued</div><div style={{fontFamily:fontMono,fontSize:10,color:T.muted,margin:"3px 0 10px"}}>Selected: {selected.length}</div><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>{items.filter(i=>i.status==="available").map(i=><button key={i.id} onClick={()=>setSelected(s=>s.includes(i.id)?s.filter(x=>x!==i.id):[...s,i.id])} style={{padding:14,border:`1.5px solid ${T.ink}`,background:selected.includes(i.id)?T.chart:T.card,fontFamily:fontMono,fontWeight:700,boxShadow:"2px 2px 0 #17171B"}}>▣ {i.id}<div style={{fontSize:8,color:T.muted,marginTop:3}}>{i.type}</div></button>)}</div><div style={{marginTop:12,display:"flex",gap:8}}><Btn disabled={!selected.length} onClick={()=>setModal({type:"issue",itemIds:selected})}>Assign selected</Btn><Btn color={T.card} textColor={T.ink} onClick={()=>setSelected([])}>Clear</Btn></div></Card></section><section><SectionHead kicker="ONE-TAP EXCEPTIONS" title="Outstanding at wrap"/><div style={{display:"grid",gap:8}}>{items.filter(i=>i.status==="issued").map(i=><Card key={i.id}><div style={{display:"flex",justifyContent:"space-between",gap:8}}><div><strong style={{fontFamily:fontMono}}>{i.id}</strong><div style={{fontFamily:fontHead,fontWeight:700}}>{crewById[i.holderId]?.name} · {crewById[i.holderId]?.dept}</div><div style={{fontFamily:fontMono,fontSize:9,color:T.muted}}>OUT {i.out} · CH {i.channel}</div></div><Btn small onClick={()=>setModal({type:"return",item:i})}>Return</Btn></div></Card>)}</div></section></>}

        {view==="CREW"&&<><SectionHead kicker={`${crew.length} PEOPLE · IMPORT-READY STRUCTURE`} title="Crew directory" right={<Btn small color={T.chart} textColor={T.ink} onClick={()=>setModal({type:"addCrew"})}>+ Crew</Btn>}/><div style={{display:"grid",gap:8}}>{crew.map(c=>{const assigned=items.filter(i=>i.holderId===c.id);return <Card key={c.id}><div style={{display:"flex",justifyContent:"space-between",gap:10}}><div><div style={{fontFamily:fontHead,fontWeight:800,fontSize:17}}>{c.name}</div><div style={{fontFamily:fontMono,fontSize:9,color:T.muted}}>{c.dept} · {c.role}</div></div>{assigned.length?<Tape color={T.orange}>{assigned.map(i=>i.id).join(", ")}</Tape>:<Tape color={T.chart}>NO KIT</Tape>}</div></Card>})}</div></>}

        {view==="CHANNELS"&&<><SectionHead kicker="ONE LIVING CHANNEL MAP" title="Channels"/><div style={{display:"grid",gap:8}}>{channels.map((c,idx)=><Card key={c.ch} style={{display:"grid",gridTemplateColumns:"50px 1fr",alignItems:"center"}}><div style={{fontFamily:fontHead,fontWeight:800,fontSize:28}}>CH {c.ch}</div><input value={c.label} onChange={e=>setChannels(xs=>xs.map((x,j)=>j===idx?{...x,label:e.target.value}:x))} style={{border:`1.5px solid ${T.ink}`,padding:10,fontFamily:fontMono}}/></Card>)}</div><div style={{fontFamily:fontMono,fontSize:9,color:T.muted}}>Changes save instantly on this device and are ready to sync when connected.</div></>}

        {view==="AUDIT"&&<><SectionHead kicker={`${audit.length} IMMUTABLE MOVEMENTS`} title="Audit history" right={<Btn small color={T.card} textColor={T.ink} onClick={reset}>Reset demo</Btn>}/><div style={{display:"grid",gap:7}}>{audit.length?audit.map(a=><Card key={a.id}><div style={{display:"flex",gap:10}}><div style={{fontFamily:fontMono,fontWeight:700,width:45}}>{a.time}</div><div><Tape color={a.action==="DAMAGE"?T.pink:a.action==="CHECK OUT"?T.orange:a.action==="CHECK IN"?T.chart:T.blue} dark={a.action==="DAMAGE"}>{a.action}</Tape><div style={{fontFamily:fontHead,fontWeight:800,marginTop:4}}>{a.itemId}</div><div style={{fontFamily:fontMono,fontSize:9,color:T.muted}}>{a.detail}</div></div></div></Card>):<Card>No movements logged yet.</Card>}</div></>}
      </main>
    </div>

    {modal&&<Modal modal={modal} crew={crew} channels={channels} onClose={()=>setModal(null)} onIssue={issue} onCheckIn={checkIn} onDamage={markDamage} onAddItem={addItem} onAddCrew={addCrew}/>} 
    {toast&&<div style={{position:"fixed",left:14,right:14,bottom:18,zIndex:80,background:T.ink,color:T.chart,padding:"13px 15px",fontFamily:fontMono,fontSize:12,boxShadow:"3px 3px 0 rgba(23,23,27,.4)"}}>✓ {toast}</div>}
  </div>
}

function Modal({modal,crew,channels,onClose,onIssue,onCheckIn,onDamage,onAddItem,onAddCrew}){
  const [holder,setHolder]=useState(crew[0]?.id||""); const [channel,setChannel]=useState(channels[0]?.ch||1); const [condition,setCondition]=useState("Good"); const [notes,setNotes]=useState("");
  const [form,setForm]=useState({id:"",type:"Walkie",serial:"",rental:"Highland Comms",cost:"",notes:"",name:"",dept:"AD",role:"",phone:""});
  const title={issue:"Issue kit",return:"Return kit",damage:"Damage report",addItem:"Add inventory",addCrew:"Add crew"}[modal.type];
  return <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:70,background:"rgba(23,23,27,.72)",display:"flex",alignItems:"flex-end"}}><div onClick={e=>e.stopPropagation()} style={{background:T.paper,width:"100%",maxHeight:"88vh",overflowY:"auto",padding:16,borderTop:`6px solid ${modal.type==="damage"?T.pink:T.chart}`}}><SectionHead kicker="SPRINT 1 WORKFLOW" title={title}/>
    {modal.type==="issue"&&<div style={{display:"grid",gap:10}}><div style={{fontFamily:fontMono,fontSize:11}}>{modal.itemIds.join(", ")}</div><Select label="ASSIGN TO" value={holder} onChange={e=>setHolder(e.target.value)}>{crew.map(c=><option key={c.id} value={c.id}>{c.name} — {c.dept}</option>)}</Select><Select label="CHANNEL" value={channel} onChange={e=>setChannel(e.target.value)}>{channels.map(c=><option key={c.ch} value={c.ch}>CH {c.ch} — {c.label}</option>)}</Select><Btn onClick={()=>onIssue(modal.itemIds,holder,channel)}>Confirm issue</Btn></div>}
    {modal.type==="return"&&<div style={{display:"grid",gap:10}}><div style={{fontFamily:fontHead,fontWeight:800,fontSize:20}}>{modal.item.id}</div><Select label="RETURN CONDITION" value={condition} onChange={e=>setCondition(e.target.value)}><option>Good</option><option>Minor wear</option><option>Damaged</option></Select><Field label="NOTES" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Optional"/><Btn onClick={()=>onCheckIn(modal.item.id,condition,notes)}>Confirm return</Btn></div>}
    {modal.type==="damage"&&<div style={{display:"grid",gap:10}}><div style={{fontFamily:fontHead,fontWeight:800,fontSize:20}}>{modal.item.id}</div><Field label="WHAT IS WRONG?" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="e.g. broken antenna"/><Btn color={T.pink} onClick={()=>onDamage(modal.item.id,notes)}>Log damage</Btn></div>}
    {modal.type==="addItem"&&<form onSubmit={e=>{e.preventDefault();onAddItem(form)}} style={{display:"grid",gap:10}}><Field required label="UNIT ID" value={form.id} onChange={e=>setForm({...form,id:e.target.value})} placeholder="W-07"/><Select label="TYPE" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{["Walkie","Battery","Headset","Charger","Accessory","Other"].map(x=><option key={x}>{x}</option>)}</Select><Field label="SERIAL" value={form.serial} onChange={e=>setForm({...form,serial:e.target.value})}/><Field label="RENTAL HOUSE" value={form.rental} onChange={e=>setForm({...form,rental:e.target.value})}/><Field label="UNIT COST (£)" type="number" value={form.cost} onChange={e=>setForm({...form,cost:e.target.value})}/><Field label="NOTES" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/><Btn>Save item</Btn></form>}
    {modal.type==="addCrew"&&<form onSubmit={e=>{e.preventDefault();onAddCrew(form)}} style={{display:"grid",gap:10}}><Field required label="NAME" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/><Field required label="DEPARTMENT" value={form.dept} onChange={e=>setForm({...form,dept:e.target.value})}/><Field label="ROLE" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}/><Field label="PHONE" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/><Btn>Save crew member</Btn></form>}
    <div style={{marginTop:12}}><Btn color={T.card} textColor={T.ink} onClick={onClose}>Close</Btn></div>
  </div></div>
}
