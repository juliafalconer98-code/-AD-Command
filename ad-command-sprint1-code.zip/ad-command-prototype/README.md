# AD Command — Sprint 1

Working React/Vite implementation of Module A: Walkie & Kit Command.

## Included
- Persistent offline local data
- Live inventory dashboard and exception counts
- Search and status/type filters
- Single-item issue and return flows
- Batch issue workflow
- Crew directory and assignments
- Editable channel map
- Battery level and charging states
- Damage logging and condition-on-return
- Permanent audit history
- CSV reconciliation export
- Installable PWA shell and service worker

## Run locally
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

The current build uses browser localStorage as the offline device database. The next engineering step for a multi-device pilot is replacing that adapter with SQLite/IndexedDB plus authenticated sync, without changing the user workflow.
